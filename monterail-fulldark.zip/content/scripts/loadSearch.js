function onLoad(activatedWhileWindowOpen) {
  WL.injectCSS("chrome://MonterailFDOverlay/content/skin/searchWindow.css");
}
  
function onUnload(deactivatedWhileWindowOpen) {
}
